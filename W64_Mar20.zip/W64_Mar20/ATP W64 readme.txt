PEW RESEARCH CENTER
Wave 64 American Trends Panel 
Dates: March 19 - March 24,2020
Mode: Web
Sample: Full panel
Language: English and Spanish
N=11,537

***************************************************************************************************************************
NOTES



***************************************************************************************************************************
WEIGHTS 

WEIGHT_W64 is the weight for the sample. Data for all Pew Research Center reports are analyzed using this weight.


***************************************************************************************************************************
Releases from this survey:

March 26, 2020 "Worries About Coronavirus Surge, as Most Americans Expect a Recession � or Worse"
https://www.people-press.org/2020/03/26/worries-about-coronavirus-surge-as-most-americans-expect-a-recession-or-worse/

March 26, 2020 "Most Americans are confident hospitals can handle the needs of the seriously ill during COVID-19 outbreak"
https://www.pewresearch.org/fact-tank/2020/03/26/most-americans-are-confident-hospitals-can-handle-the-needs-of-the-seriously-ill-during-covid-19-outbreak/

March 30, 2020 "Most Americans Say Coronavirus Outbreak Has Impacted Their Lives"
https://www.pewsocialtrends.org/2020/03/30/most-americans-say-coronavirus-outbreak-has-impacted-their-lives/

March 30, 2020 "People financially affected by COVID-19 outbreak are experiencing more psychological distress than others"
https://www.pewresearch.org/fact-tank/2020/03/30/people-financially-affected-by-covid-19-outbreak-are-experiencing-more-psychological-distress-than-others/

March 31, 2020 "Americans turn to technology during COVID-19 outbreak, say an outage would be a problem"
https://www.pewresearch.org/fact-tank/2020/03/31/americans-turn-to-technology-during-covid-19-outbreak-say-an-outage-would-be-a-problem/

***************************************************************************************************************************
